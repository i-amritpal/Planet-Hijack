#include <iostream>
using namespace std;
void disp_binary (unsigned u);
union un
{
short int i;
char ch[2];
};

int main()
{
un unt;
cin >> unt.i;
disp_binary(unt.ch[0]);
disp_binary(unt.ch[1]);
char t = unt.ch[0];
unt.ch[0] = unt.ch[1];
unt.ch[1] = t;
disp_binary(unt.ch[0]);
disp_binary(unt.ch[1]);
}
// Display the bits within a byte. 
void disp_binary(unsigned u)
{
	register int t;
	for (t = 128; t > 0; t = t / 2)
		if (u & t)
			cout << "1 ";
		else
			cout << "0 ";
	cout << "\n"
}