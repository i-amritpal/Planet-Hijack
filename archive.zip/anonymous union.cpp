#include <iostream>
using namespace std;

int main ()
{
union{
char a;
char b;
};
a = 'A';
cout << b;
}