# include <iostream>
using namespace std;

class queue
{
	int c;
	int q[10];
  public:
	int get();
	  queue();
	   void put(int k);
};
int queue::get()
{
	if (c < 0)
	{
		cout << "queue underflow";
		return 0;
	}
	c--;
	return q[c + 1];
}

void queue::put(int k)
{
	if (c == 10)
	{
		cout << " queue overflow";
		return;
	}
	q[c] = k;
	c++;
}

queue::queue()
{
	c = 0;
}

int main()
{
	queue qa[2];
	for (int j = 0 , m = 1; j < 2; j++)
	{
		for (int i = 0; i < 10; i++)
		{
			qa[j].put(i + m);
		}
		m++;
	}

	for (int i = 0; i < 10; i++)
		cout << qa[0].get() << ' ' ;
cout << "\n";
	for (int i = 0; i < 10; i++)
		cout << qa[1].get() << ' ';
}