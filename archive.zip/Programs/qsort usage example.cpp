#include<iostream>
#include<cstdlib>
#include<cstring>

using namespace std;

int cmp(const void *p1, const void *p2)
{
	return *(int *)p1 - *(int *)p2;
}

int main()
{
	int (*fp) (const void *p1, const void *p2);
	fp = cmp;
	int s[] = { 1, 7, 3, 56, 4, 5 };
	qsort(s, 6, sizeof(int), fp);
	for (int i = 0; i < 6; i++)
		 cout << s[i] << ' ';
	return 0;
}