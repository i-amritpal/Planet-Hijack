// Everything in one single spaced

#include<iostream>
using namespace std;

void showflags(ios::fmtflags f)
{
	long i;

	for (i = 0x4000; i; i = i >> 1)
	{
		if (f & i)
			cout << "1 ";
		else
			cout << "0 ";
	}
	cout << '\n';
}

int main()
{

// Uses the ios member functions
	ios::fmtflags fg;
	fg = cout.flags();

	cout << 123 << '\n';

	showflags(fg);

	cout.setf(ios::showpos);
	cout << 123 << '\n';

	fg = cout.flags();
	showflags(fg);

	cout.precision(3);
	cout.width(10);

	cout << 123 << ' ' << 123.3 << '\n';

	fg = cout.flags();

	showflags(fg);

	cout.fill('#');
	cout.width(12);

	cout << 123 << ' ' << 123.3 << '\n';

	char t = cout.fill();

	cout << t;

	return 0;
}