// Find first three most common word (most repeated) in the given string
#include<iostream>
#include<cstring>
using namespace std;

void findCommonString(char *s)
{
	int slen = strlen(s);
	char temp[20][20];
	int word = 0;
	int wordchar = 0;

	// find out words and seperate out them to different slots of array 'temp'
	for (int i = 0; i <= slen; i++)
	{
		if (s[i] != ' ' && s[i] != '.')
		{
			temp[word][wordchar] = s[i];
			wordchar++;
		}
		else
		{
			temp[word][wordchar] = '\0';
			word++;
			wordchar = 0;
		}
	}

	// Create a map of the words which contains: 
	// 1.number of times a word occurs
	// 2. the actual position of word in the 'temp' word list
	int map[20][2];
	int m = 0;
	for (int i = 0; i <= word; i++)
	{
		map[i][0] = 1;
		map[i][1] = i;
		for (int k = 0; k <= word; k++)
		{
			if (i != k)
			{
				if (strcmp(temp[i], "\0"))
				{
					if (!strcmp(temp[i], temp[k]))
					{
						map[i][0]++;
						strcpy(temp[k], "\0");
					}
				}
			}
		}
	}

	// sorting the map's "no. of times a word occur" part and
	// copying its position part to new sorted position
	int temp_var;
	for (int y = 0; y < word; y++)
	{
		for (int a = 0; a < word; a++)
		{
			if (map[a][0] < map[a + 1][0])
			{
				temp_var = map[a + 1][0];
				map[a + 1][0] = map[a][0];
				map[a][0] = temp_var;

				temp_var = map[a + 1][1];
				map[a + 1][1] = map[a][1];
				map[a][1] = temp_var;
			}
		}
	}
	// Hence displaying the first three most occured words
	for (int n = 0; n < 3; n++)
	{
		if (map[n][0] != 1)
		{
			cout << temp[map[n][1]] << ' ' << map[n][0] << '\n';
		}

	}
}

int main()
{
	char s[70];
	cin.getline(s, 70);
	findCommonString(s);
}