#include <iostream>
using namespace std;
struct t
{
	int a;
	int b;
};
t &fb(t & vt);
void f(t & vt);
int main()
{
	t st;
	t st2;
	st.a = 2;
	st.b = 2;
	cout << st.a << ' ' << st.b;
	f(st);
	st2 = fb(st);
	 cout << st2.a << ' ' << st2.b;
}

void f(t & vt)
{
	vt.a *= 2;
	vt.b *= 2;
}

t & fb(t & vt)
{
	vt.a *= 2;
	vt.b *= 2;
}