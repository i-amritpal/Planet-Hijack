 #include<iostream>

using namespace std;

struct cn
{
	int re;
	int im;
	cn operator+(cn & n1)
	{
		cn temp;
		  temp.re = re + n1.re;
		  temp.im = im + n1.im;
		  return temp;
	}
	cn(int r, int i)
	{
		re = r;
		im = i;
	}
	cn()
	{
		re = im = 0;
	}
	friend ostream & operator<<(ostream & stream, cn n1);
};

ostream & operator<<(ostream & stream, cn n1)
{
	if (n1.im < 0)
	{
		stream << n1.re << "-" << (-1*n1.im) << "i ";
	}
	else
	{
		stream << n1.re << "+" << n1.im << "i ";
	}
	return stream;
}

int main()
{
	cn a(1, -2);
	cn b(-3, 5);
	cout << a << endl;
	cout << b << endl;
	cout << a + b;
	return 0;
}