#include <iostream>
#include <cstring>
using namespace std;

void mystrcat(char *s, char *ss, int len = -1);

int main()
{
	char str1[80] = "This is a test";
	char str2[80] = "0123456789";
	mystrcat(str1, str2, 5);	// concatenate 5 chars
	cout << str1 << '\n';
	strcpy(str1, "this is a test");	// reset str1 
	mystrcat(str1, str2);		// concatenate entire string 
	cout << str1 << '\n';
	return 0;
}

void mystrcat(char *s, char *ss, int len)
{
	while (*s)
		s++;
	if (len == -1)
		len = strlen(ss);

	while (*ss && len)
	{
		*s = *ss;
		s++;
		ss++;
		len--;
	}
	*s = '\n';
}