#include <iostream>
#include<cstring>
using namespace std;
 struct addr
{
	int street;
	int house;
};
struct emp
{
	int number;
	char name[80];
	addr address;
};
int main ()
{
emp empa;
strcpy (empa.name, "john");
empa.number= 9987;
empa.address.house = 124;
empa.address.street = 3;
}