// Created by Simranjit Singh - 1/3/2016
#include <iostream>
using namespace std;
int main()
{
	int x = 12345;
	int answer;
	for (int i = 10, k = 10000; i <= 100000; i *= 10, k /= 10)
	{
		if ((i / 10) != 1)
		{
			answer += ((((x % i) - x % (i / 10)) / (i / 10)) * k);
			/* 
			   What is happening here is
               consider second iteration of i = 100

			   1. (x%i) caculates the remainder which in second loop of i =100 
			   can be 12345 % 100 = 45

			   2. We want only '4' not 45 with 5 also, so we subtract x%(i/10) 
			   from it, i.e 12345%(100/10) = 5

			   (x%i) is subtracted by x%(i/10) i.e 45 - 5 = 40

			   3. we want only face value '4' not 40 so we divide it by (i/10)
			   i.e 40 / (100/10) = 4

			   4. As a final calculation step we multiply it with k to get one
			   place value i.e 4*1000 = 4000;

			   6. now we add it to our resultant number 'answer' i.e answer +=
			   4000 so at this point answer will be 54000 */
		}
		else
		{
			answer += (x % i) * k;
			// it runs only first time, 
			// when answer = 0 and i = 10
			// answer += (12345%10)* 10000
			// answer += 50000 i.e answer = 50000

		}
	}
	cout << answer;
}