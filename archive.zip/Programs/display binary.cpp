// Program to display binary representation of number
#include <iostream>
using namespace std;

void disp_binary(unsigned char u);

int main()
{
	short int i = 0;
	cout << "Enter the number to be displayed in binary: ";
	cin >> i;
	disp_binary(i);
}

// Display the bits within a byte. 
void disp_binary(unsigned char u)
{
	register int t;
	for (t = 512; t > 0; t = t / 2)
		if (u & t)
			cout << "1 ";
		else
			cout << "0 ";
	cout << "\n";
}