#include <iostream>
#include <string>

using namespace std;

int main()
{
	string board;
	string word = "goosebumps";
	int p1, p2;
	p1 = 1;
	p2 = 3;
	int word_length = word.length();
	bool is_skip = 0;
	for (int i = 0; i < word_length; i++)
	{
		if (i == p1)
		{
			board = board + word[i];
			// cout << word[i] << " ";
			is_skip = 1;
		}
		if (i == p2)
		{
			 board = board + word[i];
			// cout << word[i] << " ";
			is_skip = 1;
		}


		if (is_skip == 0 && i != word_length)
		{
			board = board + "_";
			// cout << "_";
		}

		is_skip = 0;
	}

	cout << board << endl;
	return 0;
}