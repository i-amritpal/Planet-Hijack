#include <iostream>
	using namespace std;
struct bitfield
{
	unsigned i:1;
	unsigned k:3;
};
int main()
{
	bitfield bf;
	bf.i = 1;
	cout << bf.i;
	bf.k = 7;
	cout << bf.k;
}