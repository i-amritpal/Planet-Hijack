
#include <iostream>
	using namespace std;

enum apple
{ red, yellow, orange, pink };
char fruit[][20] = {
	"red apple",
	"yellow apple",
	"orange apple",
	"pink apple",
};

int main()
{
	typedef float balance;
	balance overdue = 23.7;
	apple appy;
	appy = red;
	cout << fruit[appy] << "\n" << overdue;

	appy = yellow;
	cout << fruit[appy];

	appy = pink;
	cout << fruit[appy];
}