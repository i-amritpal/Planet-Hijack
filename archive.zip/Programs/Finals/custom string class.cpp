// Implementing own string class
#include <iostream>
#include <cstring>
	using namespace std;
const int SIZE = 80;
class str
{
	char s[SIZE];
  public:
	  str(char *strng)
	{
		strcpy(s, strng);
	}
	str()
	{
		strcpy(s, " ");
	}
	str operator-(str ob);
	str operator+(str ob);
	str operator=(str ob);
	str operator+(char *st);
	str operator=(char *string);
	void show();
	friend str operator+(char *st, str ob);
};

str operator+(char *st, str ob)
{
	str temp;
	strcpy(temp.s, st);
	strcat(temp.s, ob.s);
	return temp;
}

str str::operator+(str ob)
{
	str temp;
	strcpy(temp.s, this->s);
	strcat(temp.s, ob.s);
	return temp;
}

str str::operator=(str ob)
{
	strcpy(this->s, ob.s);
	return *this;
}

str str::operator+(char *st)
{
	str temp;
	strcpy(temp.s, this->s);
	strcat(temp.s, st);
	return temp;
}

str str::operator=(char *string)
{
	str temp;
	strcpy(s, string);
	strcpy(temp.s, s);
	return temp;
}

void str::show()
{
	cout << s << '\n';
}

str str::operator-(str ob)
{
	str final;
	int temp[SIZE];
	int len = strlen(s);
	int objlen = strlen(ob.s);
	int l = 0;
	int prevn;
	int n = prevn = 0;
	bool found = false;
	for (int i = 0; i < len; i++)
	{
		if (ob.s[0] == s[i])
		{
			for (int m = 0; m < objlen; m++)
			{
				if (ob.s[m] == s[i + m])
				{
					l++;
				}
			}
			if (l == objlen)
			{
				for (; n < prevn + l; n++)
				{
					temp[n] = i + (n - prevn);
				}
				prevn = n;
				l = 0;
				found = true;
			}
			else
				l = 0;
		}
	}
	if (found == true)
	{
		int d = 0;
		int h = 0;
		for (int y = 0; y < len; y++)
		{
			// fcngfnfhfh
			if (y != temp[h])
			{
				final.s[d] = s[y];
				d++;
			}
			else
				h++;
		}
		final.s[d] = '\0';
	}
	else
	{
		return *this;
	}
	return final;
}

int main()
{
	str a, b;
	a = "This";
	b = a + " is a test";
	b.show();
	str c("is");
	str name;
	name = b - c;
	name.show();
	return 0;
}