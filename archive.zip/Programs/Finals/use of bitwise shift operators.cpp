#include <iostream>
using namespace std;
void disp_binary(unsigned u);
void disphighbinary(unsigned u);

int main()
{
	int i, j;
	i = 1;
	for (j = 0; j < 8; j++)
	{
		 disp_binary(i);
		i = i << 1;
	}
	i = i >> 1;
	cout << "\n";
	for (j = 0; j < 8; j++)
	{
		disp_binary(i);
		i = i >> 1;
	}
}

void disp_binary(unsigned u)
{
	register int t;
	for (t = 128; t > 0; t = t / 2)
		if (u & t)
			cout << "1 ";
		else
			cout << "0 ";
	cout << "\n";
}

void disphighbinary(unsigned u)
{
	for (int i = 32768; i > 0; i /= 2)
	{
		if (u & i)
			cout << '1';
		else
			cout << '0';
		if (i == 256)
			cout << ' ';
	}
	cout << "\n";
}