#include <iostream>
using namespace std;

void mytoupper(char *s);

int main()
{
	char sst[20] = "thistest is done";
	for (int i = 0; sst[i]; i++)
		cout << sst[i];
	mytoupper(sst);
	for (int i = 0 ; sst[i]; i++)
		cout << sst[i];
}

void mytoupper(char *s)
{
	for (int i = 0; s[i]; i++)
	{
		if (s[i] != ' ')
			s[i] = s[i] & 223;
	}
}