#include<iostream>
using namespace std;

void showflags(ios::fmtflags f)
{
	long i;

	for (i = 0x4000; i; i = i >> 1)
	{
		if (f & i)
			cout << "1 ";
		else
			cout << "0 ";
	}
	cout << '\n';
}

int main()
{
	ios::fmtflags fg;
	fg = cout.flags();

	cout << 123 << '\n';

	showflags(fg);

	cout.setf(ios::showpos);
	cout << 123 << '\n';

	fg = cout.flags();

	showflags(fg);
	 return 0;
}