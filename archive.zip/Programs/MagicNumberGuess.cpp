				// ***Guess the Magic number***
	// By Simranjit Singh
#include <iostream>
#include <cstdlib>
	using namespace std;

int main()
{

	int magic;
	int guess;

	magic = rand() % 10 + 1;
	cout << "***Magic Number Guess Program*** \n(Between 1 and 10)";
//	cout << " Programmer's hint " << magic << "\n";
	cout << "\n Enter the Guess number: ";
	cin >> guess;
	if (guess == magic)
	{
		cout << "***Right***";
	}
	else
	{
		cout << "Wrong!";
	}
	return 0;
}