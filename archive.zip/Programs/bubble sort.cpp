// Min Max
#include <iostream>
#include <cstdlib>
 using namespace std;
int main()
{
	int x, min, max;
	int list[10];
	for (x = 0; x < 10; x++)
	{
		list[x] = (rand() / 1000);
	}
	min = list[0];
	max = list[0];
	for (x = 0; x < 10; x++)
	{
		if (min > list[x])
			min = list[x];
	}
	for (x = 0; x < 10; x++)
	{
		if (max < list[x])
			max = list[x];
	}
	for (x = 0; x < 10; x++)
	{
		cout << list[x] << " ";
	}
	cout << " min " << min << "\n" << "max " << max;
	return 0;
}