#include<iostream>
#include<fstream>
#include<cstdlib>

using namespace std;

int main(int argc, char *argv[])
{
	fstream out(argv[1], ios::in | ios::out | ios::binary);

	if (!out)

	{
		cout << "File not opened\n";
		return 1;
	}

	int pos = out.tellp();

	cout << pos << endl;
	char c;
	for (register int i = 0; i < 5; i++)
		out.get(c);
	out.seekp(atoi(argv[2]), ios::end);
	out.put('&');

	out.close();
	return 0;
}