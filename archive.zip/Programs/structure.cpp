#include <iostream>
using namespace std;
struct car
{
	char name[20];
	int price;
	int mileage;
} cars[10];
void display(car vart);
void display(car * vart);
int main()
{
	car mycar;
	cout << "enter car name: ";
	cin >> mycar.name;
	cout << "enter car price: ";
	cin >> mycar.price;
	cout << "enter car mileage: ";
	cin >> mycar.mileage;
	car testcar = mycar;
	car *ptcar;
	ptcar = &testcar;
	display(testcar);
	display(ptcar);
}

void display(car vart)
{
	cout << "\n " << vart.name << " " << vart.price << " " << vart.mileage;
}

void display(car * vart)
{
	cout << "\n " << vart->name << " " << vart->price << " " << vart->mileage;
}