// Program to compare two files using file streams
#include<iostream>
#include<fstream>
	using namespace std;

int main(int argc, char *argv[])
{
	register int i;
	unsigned char buf1[1024];
	unsigned char buf2[1024];

	if (argc != 3)
	{
		cout << "Usage <file1> <file2>" << endl;
		return 1;
	}

	ifstream f1(argv[1], ios::in | ios::binary);
	if (!f1)
	{
		cout << "File1 not opened" << endl;
		return 1;
	}

	ifstream f2(argv[2], ios::in | ios::binary);
	if (!f2)
	{
		cout << "File2 not opened" << endl;
		f1.close();
		return 1;
	}

	cout << "Comparing files..." << endl;

	do
	{
		f1.read((char *)buf1, sizeof buf1);
		f2.read((char *)buf2, sizeof buf2);

		if (f1.gcount() != f2.gcount())
		{
			cout << "Files differ in size" << endl;
			f1.close();
			f2.close();
			return 1;
		}

		for (i = 0; i < f1.gcount(); i++)
		{
			if (buf1[i] != buf2[i])
			{
				cout << "Files differ" << endl;
				f1.close();
				f2.close();
				return 1;
			}
		}

	}
	while (!f1.eof() && !f2.eof());


	cout << "Files are same" << endl;
	f1.close();
	f2.close();
	return 0;
}