// Everything in one single spaced
#include<iostream>
#include<iomanip>
using namespace std;
int main()
{
// uses the manipulators function
/*cout << setprecision(2) << 123.234 << endl;
cout << setw(20) << "Hello There" << endl;

cout << setiosflags(ios::showpos | ios::scientific) << 123 << ' ' << 123.345 << endl;
*/
char s[80];
cin >> ws >> s;
cout << s << endl;
	return 0;
}