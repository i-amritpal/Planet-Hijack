#include <iostream>
#include <ctime>

using namespace std;

int main ()
{
time_t vt = time('\0');
time_t *pt = &vt;
tm* stm = localtime(pt);
char* ttm = asctime(stm);
cout << ttm;
cout << "\n " << stm->tm_hour << " : " << stm->tm_min << " : " << stm->tm_sec;

}