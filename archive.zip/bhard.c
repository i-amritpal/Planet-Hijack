#include <stdio.h>
char **get2d();
int main()
{
char** ab;
ab = get2d();
printf(ab[0]);
return 0;
}
char **get2d()
{
char *a[10]= {
"bhardwaj","sce"};
return a;
}