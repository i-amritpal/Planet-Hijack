#include <iostream>
int main()
{
int x  =12345;
int answer;
for( int i =10, int k = 100000; i<= 100000 ; i *= 10, k /= 10)
{
answer += (x % i)*k;
}
cout << k;
}