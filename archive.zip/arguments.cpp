#include <iostream>

using namespace std;

int cstrlen(char *str);

int main()
{
cout << cstrlen("hello");
}

int cstrlen(char *str)
{
int i;
for( i=0; str[i]; i++);
return i;
}