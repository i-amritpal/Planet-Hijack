#include <iostream>

using namespace std;

class vehicles
{
  protected: int wheels;
	int seats;
  public:
	void set_wheels(int a)
	{
		wheels = a;
	}
	void set_seats(int b)
	{
		seats = b;
	}
	void show()
	{
		cout << "wheels: " << wheels << " seats:" << seats << '\n';
	}
};

class truck:public vehicles
{
	int cargo;
  public:
	void set_cargo(int k)
	{
		cargo = k;
	}
	void show_truck()
	{
		show();
		cout << " cargo: " << cargo;
	}
};

int main()
{
	truck suv;
	suv.set_wheels(18);
	suv.set_seats(6);
	suv.set_cargo(1200);
	suv.show_truck();
	return 0;
}