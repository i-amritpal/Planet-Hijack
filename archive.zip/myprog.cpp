#include <iostream>
using namespace std;
int main ()
{
int *p;
int k;
k = 0;
p = &k;
if(*p) cout << *p;
}