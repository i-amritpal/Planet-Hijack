#include<iostream>

using namespace std;

class cl
{
	int i;
  public:
	  cl();
	 ~cl();
	void set(int k);
	int get();
};

cl::cl()
{
	i = 0;
}

cl::~cl()
{
	cout << "destructed";
}

void cl::set(int k)
{
	i = k;
}

int cl::get()
{
	return i;
}

int main()
{
cl obj;
obj.set(9);
cout << obj.get();

}