#include<iostream>
#include<cstdlib>

using namespace std;

class myE
{
	char e[80];
  public:
	  myE(char *s)
	{
		strcpy(e, s);
	}
};

int main()
{

	return 0;
}