// friend functions
#include <iostream>

using namespace std;

class ts{
int a;
int b;

public:
void set(int k ,int j){ a =k; b= j;}
void get();
friend void mult(ts *obj);
};

void mult(ts *obj)
{
obj->a *= 2;
obj->b *= 2;
}
void ts::get()
{
cout << a << ' ' << b;
}
int main ()
{
ts ac;
ac.set(3,6);
ac.get();
cout << '\n';

mult(&ac);
ac.get();
}