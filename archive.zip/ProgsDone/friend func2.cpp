// friend functions
#include <iostream>

using namespace std;

const int IDLE = 1;
const int BUSY = 0;

class b;

class a
{
	int status;
	// cvcvcvcvcv
  public:
	void set(int ad)
	{
		status = ad;
	}
	void popchk(b bk);
};

class b
{
	int status;

  public:
	void set(int ad)
	{
		status = ad;
	}
	friend void a::popchk(b bk);
};

void a::popchk(b bk)
{
	if (status && bk.status)
	{
		cout << "screen available \n";
	}
	else
		cout << " screen not available \n";
}

int main ()
{
a as;
b bs;
as.set(IDLE);
bs.set(IDLE);

as.popchk(bs);

as.set(BUSY);
bs.set(IDLE);

as.popchk(bs);
return 0;
}