#include<iostream>
#include<typeinfo>
using namespace std;

class base
{
	virtual void f(){}
	// Due to this commenting out of virtual function now typeid gives base
	// for of pointer not the obj being pointed to
};

class derived1:public base
{
};

class derived2:public base
{
};

void st(base& ob)
{
cout << "Type of object is " << typeid (ob).name() << endl;
}
int main()
{
base a;
derived1 b;
derived2 c;
st(a);
st(b);
st(c);
	return 0;
}