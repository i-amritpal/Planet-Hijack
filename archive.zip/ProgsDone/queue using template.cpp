#include <iostream>
#include<cstring>
using namespace std;

//const int size = 100;

struct addr
{
	char name[40];
	char street[40];
	char city[30];
	char state[3];
	char zip[12];
};

template < class X ,int size> class queue
{
	X q[size];
	int sloc, rloc;
  public:
	queue()
	{
		sloc = rloc = 0;
	}
	void qput(X i);
	X qget();
};

template < class X ,int size> void queue < X, size >::qput(X i)
{
	if (sloc == size)
	{
		cout << "Queue full\n";
		return;
	}
	sloc++;
	q[sloc] = i;
}

template < class X,int size > X queue < X,size >::qget()
{
	if (rloc == sloc)
	{
		cout << " Queue underflow\n";
		X n;
		return n;
	}
	rloc++;
	return q[rloc];
}

int main()
{
	queue < int ,10>a;
	a.qput(67);
	a.qput(27);
	cout << a.qget();
	cout << a.qget();
	a.qget();

	queue < double ,3>b;
	b.qput(67.6);
	b.qput(2.7);
	cout << b.qget();
	cout << b.qget();
	b.qget();


	queue < addr ,10> addresses;

	addr firstaddress;
	addr secondaddress;

	strcpy(firstaddress.name, "simran");
	strcpy(secondaddress.name, " amrit");

	addresses.qput(firstaddress);
	addresses.qput(secondaddress);

	addr one = addresses.qget();
	addr two = addresses.qget();
	 cout << two.name;
	return 0;
}