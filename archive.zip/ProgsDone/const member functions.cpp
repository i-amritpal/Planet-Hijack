#include<iostream>

using namespace std;

class sv
{
	mutable int x;
	const int y;
  public:
	  sv(int a, int b): y(b)
	{
		x = a;
	}
	void set(int a) const
	{
		x = a;					// valid
		// y = a; // Not Valid
	}
	void get()
	{
		cout << x << ' ' << y << endl;
	}
};

int main()
{
	sv a(1, 6);
	a.set(7);
	a.get();
	// a = 12;// can be used if three are only 1 parameters to
	// constructor
	a.get();
	return 0;
}