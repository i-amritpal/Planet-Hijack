#include<iostream>
using namespace std;

void test(int x)
{
	if (x)
	{
		throw x;
	}
cout << "safe in test1";
}

int main()
{
try {
test(0);
test (1);
test (2);
}
catch (int a)
{
cout << " Exception caught of int value "<< a << '\n';
}
cout << " end ";
}