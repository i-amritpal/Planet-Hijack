#include <iostream>
using namespace std;

void reverse(char *str);

int main()
{
reverse("simranjit");
}

void reverse(char *str)
{
if(*str)
reverse(str+1);
else return;
cout << *str;
}