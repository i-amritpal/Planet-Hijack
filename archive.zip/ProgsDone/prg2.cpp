#include<iostream>

using namespace std;

int main()
{
	int n;
	int sum = 0;

	cout << "Enter n: ";
	cin >> n;

	for (int i = 1; i <= n; i++)
	{
		for (int k = 1; k <= i; k++)
		{
			sum += k;
		}
	}

	cout << "Sum of series is: " << sum;
	 return 0;
}