#include <iostream>
using namespace std;

int main()
{
	int i;
	int ar[3];
	char ch;
	cout << "sizeof char " << sizeof ch;
	cout << "sizeof int " << sizeof i;
	cout << "sizeof long" << sizeof(long);
	cout << "sizeof double" << sizeof(double);
	cout << "sizeof array with 3 element of int" << sizeof ar;
}