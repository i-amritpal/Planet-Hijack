#include<iostream>

using namespace std;

namespace myns
{
	int l;
	class cl
	{
		int timer;
	  public:
		  cl(int x)
		{
			timer = x;
		}
		int run()
		{
			if (timer > l)
			{
				cout << timer-- << ' ';
				return 1;
			}
			return 0;
		}
	};
}

int main()
{
	cout << "Within main \n";
	myns::l = 12;
	myns::cl ob(34);

	while (ob.run());
}