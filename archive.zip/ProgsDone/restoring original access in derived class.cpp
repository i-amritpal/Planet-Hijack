// will not compile due to deprecation...

#include <iostream>

using namespace std;

class base {
int x;
public:
int y;
void setx(int a) { x = a;}
int getx() { return x;}
};

class derived: private base{
int z;
public:

base::y;
base::setx;
base::getx;

void setz(int a){ z = a;}
int getz() { return z;}
};

int main ()
{
derived ob;
ob.setx(3);
ob.setz(5);
ob.y = 4;

cout << ob.getx() << " " << ob.y << " " << ob.getz();
return 0;
}