// Project 1 Grocery Store item Record with disk save/retrieve
#include<iostream>
#include<cstring>

using namespace std;

/* Declare the item class which contains particular item's name , price and
   quantity along with methods to be used with them */
class item
{
	char *name;
	double price;
	int quantity;

  public:
	  item(char *n, double p, int q)
	{
		// Dynamically allocate char array of the size of the string n
		name = new char[sizeof(n)];
		// Hence copy the string n to name
		  strcpy(name, n);

		  price = p;
		  quantity = q;
	}
	item()
	{
		name = 0;
		price = 0.0;
		quantity = 0;
	}

	void change_name(char *n)
	{
		// Free previously allocated memory
		delete[]name;
		// Dynamically allocate char array of the size of the string n
		name = new char[sizeof(n)];
		// Hence copy the string n to name
		strcpy(name, n);
	}
	void change_price(double p)
	{
		price = p;
	}

	void change_quantity(int q)
	{
		quantity = q;
	}

	void update(int q = -1)
	{
		quantity += q;
	}
	void debug()
	{
		cout << name << ' ' << price << ' ' << quantity << '\n';
	}
};

class store{
item product[20];

};

int main()
{
	item a("Ab", 2.3, 5);
	a.debug();
	a.change_name("Abcsd");
	a.update();
	a.debug();
}