#include <iostream>
#include <cstdlib>
using namespace std;
class three_d
{
	int x, y, z;

  public:
	void set(int i, int k, int j);
	void get();
	friend three_d operator+(three_d k, three_d obj);
	three_d operator=(three_d obj);
	three_d operator++();
	three_d operator++(int notused);
};

void three_d::set(int i, int k, int j)
{
	x = i;
	y = k;
	z = j;
}

void three_d::get()
{
	cout << x << ' ' << y << ' ' << z << '\n';
}

three_d operator+(three_d k, three_d obj)
{
	three_d temp;
	temp.x = k.x + obj.x;
	temp.y = k.y + obj.y;
	temp.z = k.z + obj.z;
	return temp;
}

three_d three_d::operator=(three_d obj)
{
	x = obj.x;
	y = obj.y;
	z = obj.z;
	return *this;
}

three_d three_d::operator++()
{
	x += 1;
	y += 1;
	z += 1;
	return *this;
}

three_d three_d::operator++(int notused)
{
	three_d temp = *this;
	x++;
	y++;
	z++;
	return temp;
}

int main()
{
	three_d c;
	three_d a;
	three_d b;
	a.set(4, 3, 4);
	b.set(1, 7, 3);
	c.set(4, 8, 6);

	a.get();
	b.get();
	c.get();

	cout << '\n';
	a = b + c;

	b = c;
	++c;
	b.get();
	a.get();
	c.get();


	cout << " ----------------";

	cout << "doing ++c;  \n";
	++c;
	c.get();

	cout << "doing c++; \n ";
	c++;
	c.get();

	cout << "doing a=  ++c; \n";
	a = ++c;
	a.get();
	c.get();

	cout << "doing a = c++; \n";
	a = c++;
	a.get();
	c.get();
	return 0;
}