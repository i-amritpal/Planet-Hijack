#include<iostream>
#include<typeinfo>
using namespace std;

template<class A> class tp{
A a;
public:
tp(A b){ a = b;}
void show(){ cout << a << endl;}
};
int main()
{

tp<int> a(5);
tp<int> b(6);
tp<double> c(5.7);

cout << "Type of a is " << typeid(a).name() << endl;
cout << "Type of b is " << typeid(b).name() << endl;
cout << "Type of c is " << typeid(c).name() << endl;
return 0;
}