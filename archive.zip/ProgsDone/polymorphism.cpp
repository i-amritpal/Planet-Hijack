#include <iostream>

using namespace std;

class figure
{
  protected:
	int x;
	int y;

  public:
	void setdim(int a, int b = 0)
	{
		x = a;
		y = b;
	}

	virtual void area()=0;

};

class rectangle:public figure
{
  public:
	void area()
	{
		cout << " Area of rect " << x << " X " << y << " is: " << x * y << endl;
	}
};

class triangle:public figure
{
  public:
	void area()
	{
		cout << "Area of Traingle of base: " << x << " and height: " << y << " is: " << 0.5 * x *
			y << endl;
	}
};

class circle:public figure
{
  public:void area()
	{
		cout << "Area of circle with radius " << x << " is: " << 3.14 * x * x << endl;
	}
};

int main()
{
	figure *p;

	rectangle r;
	triangle t;
	circle c;

	r.setdim(3, 4);
	t.setdim(5, 8);
	c.setdim(6);

	p = &r;
	p->area();

	p = &t;
	p->area();

	p = &c;
	p->area();
	 return 0;
}