// A custom version of strlen().
#include <iostream>

using namespace std;
void mystrcpy(char *str, char *st);
void mystrcat(char *str, char *st);

int main()
{
	char test3[50];
	mystrcpy(test3, "this is test");
	cout << test3;
	char test4[50];
	mystrcpy(test4, " two");
	cout << test4;
mystrcat(test3, test4);
cout << test3;
	return 0;
}								// A customversion of strlen(). 

void mystrcpy(char *str, char *st)
{
	while (*st)
	{
		*str = *st;
		str++;
		st++;
	}
}
void mystrcat(char *str, char *st)
{
int i, k;
for( i = 0; str[i]; i++);
for( k = 0; st[k]; k++);
str += i;
while(*st)
{
*str = *st;
str++;
st++;
}
str='\0';
}