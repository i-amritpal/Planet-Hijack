#include <iostream>

using namespace std;

class three_d
{
	int x, y, z;
  public:
	  three_d(int a, int b, int c)
	{
		x = a;
		y = b;
		z = c;
	}
	three_d()
	{
		x = y = z = 0;
	}
	three_d operator() (int a, int b, int c)
	{
		three_d temp;
		temp.x = x + a;
		temp.y = y + b;
		temp.z = z + c;
		return temp;
	}
	void show()
	{
		cout << x << "," << y << "," << z << '\n';
	}
};

int main()
{
	three_d ob1(1, 2, 3);
	three_d ob2 = ob1(2, 3, 4);
	ob1.show();
	ob2.show();
	 return 0;
}