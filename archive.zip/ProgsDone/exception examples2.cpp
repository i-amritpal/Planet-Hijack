#include<iostream>
#include<cstdlib>

using namespace std;

class myE
{
	char e[80];
  public:
	  myE(char *s)
	{
		strcpy(e, s);
	}
	void getE()
	{
		cout << e << '\n';
	}
};

int main()
{
	int x, y;
	x = 10, y = 3;
	try
	{
		if (!y)
		{
			throw myE("divide by zero");
		}
		else
		{
			cout << x << '/' << y << " is equal to " << x / y;
		}
	}
	catch(myE ob)
	{
		cout << "Got exception of ";
		ob.getE();
	}
	return 0;
}