#include<iostream>
#include<typeinfo>

using namespace std;

class my
{

};
int main()
{
	int a, b;
	my c;

	cout << "Type of a " << typeid(a).name() << endl;
	cout << "Type of b " << typeid(b).name() << endl;
	cout << "Type of c " << typeid(c).name() << endl;

	if (typeid(a) == typeid(b))
		cout << "a and b have same base \n";
	if (typeid(b) != typeid(c))
		cout << " b and c are of different type \n";
	 return 0;
}