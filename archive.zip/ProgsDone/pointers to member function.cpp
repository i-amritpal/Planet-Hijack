#include<iostream>

using namespace std;

class cl
{
  public:
	int x;
	void show()
	{
		cout << x << '\n';
	}
};

int main()
{
	int cl::*mp;
	void (cl::*sp) ();

	cl ob;

	mp = &cl::x;
	sp = &cl::show;

	ob.*mp = 6;
	(ob.*sp) ();

	cl *clp;

	clp = &ob;
	(clp->*sp) ();
	return 0;
}