#include<iostream>
#include<cstring>
#include<cstdlib>

using namespace std;

// Defining only five of all
char qualifier[][10] = {
	"int", "double", "char", "long", "float"
};
char qualifier2[][20] = { ";", "=", ":", "?" };

int main()
{
	string s;

	cout << "Enter the expression to be evaluated:";
	getline(cin, s);

	int slen;
	char temp[20][20];
	char final[10][20];
	int word = 0;
	int wordchar = 0;

	for (slen = 0; s[slen]; slen++);
	slen++;
	// find out words and seperate out them to different slots of array 'temp'
	for (int i = 0; i <= slen; i++)
	{
		if (s[i] != ' ')
		{
			temp[word][wordchar] = s[i];
			wordchar++;
		}
		else
		{
			temp[word][wordchar] = '\0';
			word++;
			wordchar = 0;
		}
	}

	// Find out the type qualifiers and respective adjoining objects if they
	// have valid name
	for (int m = 0; m <= word; m++)
	{
		for (int i = 0; i < 5; i++)
		{
			if (!strcmp(temp[m], qualifier[i]))
			{
				char t[20];
				strcpy(t, temp[m]);
				strcat(t, " : un");
				strcpy(final[m], t);

				if (isdigit(temp[m + 1][0]))
				{
					char t3[20];
					strcpy(t3, temp[m + 1]);
					strcat(t3, " : id(NotValid)");
					strcpy(final[m + 1], t3);

				}
				else
				{
					bool isVarNameReserved = false;
					for (int k = 0; k < 5; k++)
					{
						if (!strcmp(temp[m + 1], qualifier[k]))
							isVarNameReserved = true;
					}

					if (!isVarNameReserved)
					{
						char t2[20];
						strcpy(t2, temp[m + 1]);
						strcat(t2, " : id");
						strcpy(final[m + 1], t2);
					}
				}
			}
		}
	}
	// cout << temp[0];

	for (int m = 0; m <= word; m++)
	{
		for (int i = 0; i < 4; i++)
		{
			if (!strcmp(temp[m], qualifier2[i]))
			{
				char t[20];
				strcpy(t, temp[m]);
				strcat(t, " : un");
				strcpy(final[m], t);
			}
		}
	}

	for (int m = 0; m <= word; m++)
	{
		int c = atoi(temp[m]);
		if (c == 0 && temp[m][0] == '0')
		{
			char t[20];
			strcpy(t, temp[m]);
			strcat(t, " : num");
			strcpy(final[m], t);
		}
		else
		{
			int n, p;
			for (n = 0; temp[m][n]; n++)
			{
				if (isdigit(temp[m][n]))
				{
					p++;
				}
			}
			if (n == p)
			{
				char t4[20];
				strcpy(t4, temp[m]);
				strcat(t4, " : num");
				strcpy(final[m], t4);
			}
		}

	} 
 cout << '(';
	for (int h = 0; h <= word; h++)
	{
		cout << final[h] << " , ";
	}
	cout << ')';
	return 0;
}