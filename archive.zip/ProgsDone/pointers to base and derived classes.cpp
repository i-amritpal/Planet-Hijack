#include <iostream>
#include <cstring>

using namespace std;

class bclass
{
	char author[80];
  public:
	void setauthor(char *a)
	{
		strcpy(author, a);
	}
	void getauthor()
	{
		 cout << "Author: " << author << endl;
	}

};

class dclass:public bclass
{
	char title[80];
  public:
	void settitle(char *t)
	{
		strcpy(title, t);
	}
	void gettitle()
	{
		cout << "title: " << title << endl;
	}
};

int main ()
{
bclass ob1;
bclass *p;

dclass ob2;
dclass *dp;

p = &ob1;
p->setauthor("Simranjit");

p = &ob2;
p->setauthor("Amritpal");

ob1.getauthor();
ob2.getauthor();

dp = &ob2;
dp->settitle("acreation");
dp->gettitle();
return 0;
}