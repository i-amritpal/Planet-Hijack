#include <iostream>
using namespace std;
int dividebyzero();
int main()
{
	int i, k;
	cout << "enter no and divider nk.";
	cin >> i >> k;
	int result = k ? i / k : dividebyzero();
	cout << " \n result is " << result << "\n";
	// rubbish below
	int j = result;
	i = (j++, k += 100, k / j);
	cout << i;
	return 0;
}

int dividebyzero()
{
	cout << "error!";
	return 0;
}