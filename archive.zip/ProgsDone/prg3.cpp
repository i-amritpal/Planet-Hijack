#include<iostream>

using namespace std;

int main()
{
	int n;
	double sum = 0;

	cout << "Enter n: ";
	cin >> n;
	int i;
	double l;
double temp;
	for (l = 1,  i = 1; i <= n; i++, l += 2)
	{
		sum = sum + (1 / (l * l));
	}

	cout << "Sum of series is: " << sum;
	return 0;
}