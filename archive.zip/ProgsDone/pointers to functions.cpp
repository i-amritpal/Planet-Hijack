#include<iostream>

using namespace std;

void hline(int i), vline(int i);

int main()
{
	void (*p) (int i);

	p = vline;

	(*p) (10);

	p = hline;

	(*p) (8);

	return 0;
}

void hline(int i)
{
	while (i)
	{
		cout << '-';
		i--;
	}
	cout << endl;
}

void vline(int i)
{
	while (i)
	{
		cout << '|' << '\n';
		i--;
	}
}