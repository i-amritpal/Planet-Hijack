#include<iostream>
#include<typeinfo>
using namespace std;

void f(const int* a)
{
int *v;
cout << "Inside function\n";
v = const_cast <int*>(a);
*v = 100;
}

int main ()
{
int *p, x =99;
p = &x;
cout << x << endl;
f(p);
cout << x << endl;

int i;
char *s = "a";
i = reinterpret_cast <int> (s);
cout << i;
return 0;
}