#include<iostream>
#include<cstdlib>

using namespace std;

void Xhandler(int i)
{
	try
	{
		if (i)
			throw i;
		else
			throw "value is zero";
	}
	catch(int e)
	{
		cout << " find ex#" << e << '\n';
	}
	catch(const char *e)
	{
		cout << "found exception is string: " << e << '\n';

	}
}

int main()
{
	Xhandler(1);
	Xhandler(0);
	 Xhandler(4);
}