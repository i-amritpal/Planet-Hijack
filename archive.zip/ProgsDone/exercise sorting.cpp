#include <iostream>

using namespace std;

void minmax(double *b, double &m, double &n, int k);

int main()
{
	double a[5] = { 11.1, 5.3, 7.3, -1.5, -6.5 };
	double min = 0.0;
	double max = 0.0;
	minmax(a, min, max, 5);
	cout << min << "  " << max;
	return 0;
}

void minmax(double *b, double &m, double &n, int k)
{
	double temp;
	for (int y = 0; y < k; y++)
	{
		 for (int a = 0; a < k; a++)
		{
			if (b[a] < b[a + 1])
			{
				temp = b[a + 1];
				b[a + 1] = b[a];
				b[a] = temp;
			}
		}
	}
	m = b[k];
	n = b[0];
}