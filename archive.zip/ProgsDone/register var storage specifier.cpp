#include <iostream>
#include <ctime>

using namespace std;

unsigned int i;
unsigned int delay;
int main (){
long end,start;
register unsigned int j;
cout << "non register" ;
start = clock();
for (delay = 0; delay < 50 ; delay++) 
for (i = 0; i< 4100000; i ++);
end = clock();
cout << "time elsapsed :" << end - start << "\n";

cout << " with register ";
start = clock();
for (delay = 0; delay < 50 ; delay++) 
for (j = 0; j < 4100000; j ++);
end = clock();
cout << "time elsapsed :" << end - start << "\n";
return 0;
}