//#include <stdio.h>
#include <iostream>
using namespace std;
int main()
{
unsigned int i = 23;
signed char c =-23;
//cout << c << '\n';
//printf(c);
if( i > c) //printf("\nYes\n");
cout << "Yes\n";
else if(i < c)
//printf("\nNo\n");
cout << "No\n";
}