// intro to templates
// multiple container types
// explicit specialization

#include <iostream>
using namespace std;

template < class X > void swapArg(X & a, X & b)
{
	X temp;
	temp = a;
	a = b;
	b = temp;
	cout << "inside template \n";
}

void swapArg(int &a, int &b)
{
	int temp;
	temp = a;
	a = b;
	b = temp;
	cout << "explicit specialization out of template \n";
}

template < class tp1, class tp2 > void show(tp1 a, tp2 b)
{
	cout << a << ' ' << b << endl;
}

int main()
{
	int m = 4, n = 6;
	double g = 5.6, h = 6.9;
	char x = 'x', y = 'y';
	cout << m << ' ' << n << '\n';
	cout << g << ' ' << h << '\n';
	cout << x << ' ' << y << '\n';

	swapArg(m, n);
	swapArg(g, h);
	swapArg(x, y);
	cout << m << ' ' << n << endl;
	cout << g << ' ' << h << endl;
	cout << x << ' ' << y << '\n';

	show(34, "simran");
	show(3.5, 10L);
	return 0;
};