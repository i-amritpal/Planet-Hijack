#include <iostream>

using namespace std;

class base1 {
protected: int a;
public:
base1(int x){ a = x; cout << "constructing base1 \n";}
~base1(){ cout << "destructiong base1 \n";}
};

class base2{
protected: int b;
public:
base2(int y){ b = y; cout << "constructing base2 \n";}
~base2(){ cout << "destructiong base2 \n";}
};

class derived : public base1, public base2{
protected:
int c;
public:
derived(int z,int m,int n) : base1(m) , base2(n) {c = z; cout << "constructing derived \n";}
~derived (){ cout << "destructing derived \n";}
void show()
{
cout << a << " " << b << " " << c << endl;
}
};

int main ()
{
derived ob(5,6,7);
ob.show();
return 0;
}