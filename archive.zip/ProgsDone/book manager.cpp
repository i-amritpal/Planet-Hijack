#include<iostream>
#include<cstring>
#include<cstdlib>
#include<vector>
#include<fstream>
using namespace std;

struct book
{
	string bookName;
	string bookAuthor;
	int bookID;
  };

class library
{
	vector < book > books;

  public:
	library(char *fileName)
	{
		ifstream library(fileName, ios::in | ios::binary);
		if (!library)
		{
			cout << "Library not opened\n";
			exit(1);
		}

	}
};

int main()
{

}