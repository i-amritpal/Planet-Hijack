#include<iostream>
#include<new>
#include<cstdlib>
using namespace std;

class three_d
{
	int x, y, z;
  public:
	  three_d()
	{
		x = y = z = 0;
		cout << "creating object\n";
	}
	three_d(int a, int b, int c)
	{
		x = a;
		y = b;
		z = c;
		cout << "creating object\n";
	}

	void *operator         new(size_t size)
	{
		cout << "overloading new of 3d object\n";
		void *p;
		p = malloc(size);
		if (!p)
		{
			bad_alloc ba;
			throw ba;
		}
		return p;
	}

	void *operator        new[] (size_t size)
	{
		cout << " overloading new of array of 3d object\n";
		void *p;
		p = malloc(size);
		if (!p)
		{
			bad_alloc ba;
			throw ba;
		}
		return p;
	}

	void operator       delete(void *p)
	{
		cout << "Freeing 3d object\n";
		free(p);
	}

	void operator      delete[] (void *p)
	{
		cout << "Freeing array 3d object\n";
		free(p);
	}

	void *operator  new(size_t size, const nothrow_t & n)
	{
		cout << "overloading new of 3d object\n";
		void *p;
		p = malloc(size);
		if (!p)
		{
			return 0;
		}
		return p;
	}

	void *operator  new[](size_t size, const nothrow_t & n)
	{
		cout << "overloading new of array of 3d object\n";
		void *p;
		p = malloc(size);
		if (!p)
		{
			return 0;
		}
		return p;
	}

	~three_d()
	{
		cout << "destructing object \n";
	}

	void show()
	{
		cout << x << ' ' << y << ' ' << z << '\n';
	}
};

int main()
{
	three_d *p, *pob;
	try
	{
		p = new three_d(2, 4, 6);
		pob = new three_d[5];
	}
	catch(bad_alloc ba)
	{
		cout << " Allocation failed \n";
		return 1;
	}
	p->show();
	pob[0].show();
	delete p;
	delete[]pob;

three_d *a;
a = new (nothrow) three_d(7,7,8);
a->show();

delete a;
	return 0;
}