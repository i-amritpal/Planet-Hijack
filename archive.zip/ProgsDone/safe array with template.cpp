#include <iostream>
#include<cstdlib>
using namespace std;

template < class X, int size > class array
{
	X arr[size];
  public:
	array()
	{
		register int i;
		for (i = 0; i < size; i++)
		{
			arr[i] = i;
		}
	}
	X & operator[](int i);
};

template < class X,int size >
 X & array < X ,size>::operator[](int i)
{
	if (i < 0 || i > size - 1)
	{
		cout << "Index of " << i << " is out of bounds\n";
		exit(1);
	}
	return arr[i];
}

int main()
{
	array < int , 10>ob1;
	ob1[0 ] = 12;
	ob1[1] = 23;

	cout << ob1[0] << ' ' << ob1[1] << '\n';

	array < double ,2>ob2;
	ob2[0] = 1.2;
	ob2[1] = 2.3;

	cout << ob2[0] << ' ' << ob2[1];

ob1[233] = 0;
	return 0;
}