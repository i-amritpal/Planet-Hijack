#include <iostream>
#include<cstdlib>
using namespace std;

template < class X= int, int size = 100> class array
{
	X arr[size];
  public:
	  X & operator[] (int i);
};
template < class X, int size > X & array < X, size >::operator[] (int i)
{
	if (i < 0 || i > size - 1)
	{
		cout << "Index of " << i << " is out of bounds\n";
		exit(1);
	}
return arr[i];
}

int main ()
{
array<> a;
a[0] = 1;
cout << a[0];
}