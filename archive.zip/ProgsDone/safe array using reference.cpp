#include <iostream>
using namespace std;

int &put(int i);
int get(int i);

int ar[10];
int error = -1;

int main()
{
	put(0) = 20;
	put(3) = 223;
	cout << get(0) << "\n" << get(3) << "\n" << get(11);
	put(12) = 3;
}

int &put(int i)
{
	if (i >= 0 && i < 10)
		return ar[i];

	else
	{
		cout << "error !";
		return error;
	}
}

int get(int i)
{
	if (i >= 0 && i < 10)
		return ar[i];
	else
	{
		return error;
	}
}