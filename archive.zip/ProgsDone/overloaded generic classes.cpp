#include<iostream>

using namespace std;

template<class X> class Ca{
X a;
public:
Ca(X b){a = b;}
void show(){ cout << a << '\n';}
};

template<>class Ca<int>{
int a;
public:
Ca(int b){ a = b*b;}
void show(){ cout << a << '\n';}
};

int main ()
{
Ca<int> A(3);
Ca<double> B(7.8);
A.show();
B.show();
return 0;
}