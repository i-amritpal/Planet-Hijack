// Everything in one single spaced
#include<iostream>
#include<iomanip>
using namespace std;

ostream& setup(ostream &stream)
{
stream.setf(ios:: left);
stream << setw(10) << setfill('$');
return stream;
}

int main()
{
cout << 23 << " " << setup << 23;
	return 0;
}