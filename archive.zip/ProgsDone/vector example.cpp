#include<iostream>
#include<vector>

using namespace std;

int main()
{
	vector < int >v;			// Zero size vector

	cout << "Initial vector size: " << v.size() << endl;

	// Put value in vector
	for (int i = 0; i < 10; i++)
		v.push_back(i + 1);

	// Display current size
	cout << "Current vector size: " << v.size() << endl;

	// Display items of vector
	for (int i = 0; i < 10; i++)
		cout << v[i] << ' ';
	cout << endl;

	for (int i = 10; i < 20; i++)
		v.push_back(i + 1);

	for (int i = 10; i < 20; i++)
		cout << v[i] << ' ';
	cout << endl;

	cout << "Size of vector is: " << v.size() << endl;
	 return 0;
}