#include<iostream>

using namespace std;

class three_d
{
	int x, y, z;
  public:
	  three_d()
	{
		x = y = z = 0;
	}

	three_d(int a, int b, int c)
	{
		x = a;
		y = b;
		z = c;
	}
	friend ostream & operator<<(ostream & stream, three_d ob);

	friend istream & operator>>(istream & stream, three_d& ob);
};

ostream & operator<<(ostream & stream, three_d ob)
{
	stream << ob.x << ' ' << ob.y << ' ' << ob.z << '\n';
	return stream;
}

istream & operator>>(istream & stream, three_d& ob)
{
	cout << "Enter x, y, z values: ";
	stream >> ob.x >> ob.y >> ob.z;
	return stream;
}

int main()
{
	three_d a(3, 4, 5), b;
	cin >> b;;
	cout << a;
	cout << b;
	 return 0;
}