#include<iostream>

using namespace std;

class three_d
{
	int x, y, z;

  public:
	  three_d()
	{
		x = y = z = 0;
	}
	three_d(int a, int b, int c)
	{
		x = a;
		y = b;
		z = c;
	}
	friend ostream & operator<<(ostream & stream, three_d ob);

	three_d operator+(three_d ob)
	{
		three_d temp;
		temp.x = ob.x + x;
		temp.y = ob.y + y;
		temp.z = ob.z + z;
		return temp;
	}
	operator   int ()
	{
		return x * y * z;
	}
};

ostream & operator<<(ostream & stream, three_d ob)
{
	stream << ob.x << ',' << ob.y << ',' << ob.z << '\n';
	return stream;
}

int main()
{
	three_d a(1, 2, 3), b(4, 5, 6);
	cout << a << b;

	int h;
	h = a + 14;
	cout << h << '\n';

	three_d c;
	c = a + b;
	cout << c;
	return 0;
}