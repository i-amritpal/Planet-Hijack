#include <iostream>
using namespace std;

double arr[] = {1,2,3,4,5};
double &changer(int i);

int main()
{
cout << "Original values are " ;
for(int k =0; k <5 ; k++)
cout << arr[k] << "\n";

changer(1) = 123;
changer(4) = 231;

cout << "changed values are " ;
for(int k =0; k <5 ; k++)
cout << arr[k] << "\n";
}

double &changer(int i)
{
return arr[i];
}