//***Guess the Magic number***
// By Simranjit Singh
#include <iostream>
#include <cstdlib>

using namespace std;

int main(){

int magic;
int guess;

magic = rand();
cout << "***Magic Number Guess Program*** \n";
cout << " Programmer's hint " << magic << "\n";
cout << " Enter the Guess number: ";
cin >> guess;
if ( guess == magic )
{
cout << "***Right***";
}else{
cout << "Wrong!";
 }
return 0;
}