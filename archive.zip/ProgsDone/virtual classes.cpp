#include <iostream>

using namespace std;

class base{
public:
int i;
};

class derived1: public base{
public:
int j;
};

class derived2: public base{
public:
int k;
};

class derived3: public derived1,public derived2{
public:
int x;
};

int main()
{
derived3 ob;
ob.derived1::i = 23;
ob.j =12;
ob.k = 67;

cout << ob.derived1::i << ' ' << ob.j << ' ' << ob.k << endl;

ob.x = ob.derived1::i * ob.j;

cout << ob.x;
}