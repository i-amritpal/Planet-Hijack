#include<iostream>
#include<typeinfo>
#include<cstdlib>

using namespace std;

class figure
{
  protected:
	double x, y;
  public:
	  figure(double a, double b)
	{
		x = a;
		y = b;
	}
	virtual void area() = 0;
};

class rectangle:public figure
{
  public:
	rectangle(double m, double n):figure(m, n)
	{
	}
	void area()
	{
		cout << "Area of rect is " << x * y << endl;
	}
};

class circle:public figure
{
  public:
  circle(double m, double n = 0):figure(m, n)
	{
	}
	void area()
	{
		cout << "Area of circle is " << 3.14 * x * x << endl;
	}
};

class triangle:public figure
{
  public:
	triangle(double m, double n):figure(m, n)
	{
	}
	void area()
	{
		cout << "Area of triangle is " << 0.5 * x * y << endl;
	}
};

figure *factory()
{
	switch (rand() % 3)
	{
	case 0:
		return new rectangle(4, 5);
	case 1:
		return new circle(4, 5);
	case 2:
		return new triangle(4, 5);
	}
	return 0;
}

int main()
{
	figure *p;
	int rA=0, cA=0, tA=0;
	for (int i = 0; i < 10; i++)
	{
		p = factory();
		p->area();
		if (typeid(*p) == typeid(rectangle))
			rA++;
		else if (typeid(*p) == typeid(circle))
			cA++;
		else if (typeid(*p) == typeid(triangle))
			tA++;
	}

	cout << endl;

	cout << "Rectangles: " << rA << endl;
	cout << "Circles: " << cA << endl;
	cout << "Triangles: " << tA << endl;
	 return 0;
}