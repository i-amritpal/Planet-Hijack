#include<iostream>
#include<vector>

using namespace std;

int main()
{
	vector < char >v;
	for (int i = 0; i < 10; i++)
		v.push_back('A' + i);

	for (int i = 0; i < v.size(); i++)
		cout << v[i] << ' ';
	cout << '\n';
	vector < char >::iterator p = v.begin();
	p += 2;
	v.insert(p, 10, 'Z');
	for (int i = 0; i < v.size(); i++)
		cout << v[i] << ' ';
	cout << '\n';

	p = v.begin();
	p += 2;
	 v.erase(p, p + 10);

	for (int i = 0; i < v.size(); i++)
		cout << v[i] << ' ';
	cout << '\n';
	return 0;
}