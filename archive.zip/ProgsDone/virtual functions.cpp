#include <iostream>

using namespace std;

class base
{
  public:
	virtual void who()
	{
		cout << "base" << endl;
	}
};

class derived2:public base
{
  public:
	void who()
{
		cout << "derived2" << endl;
	}
};

class derived1:public derived2
{

};


int main ()
{
base a;
derived1 b;
derived2 c;

base *p;

p = &a;
p->who();

p = &b;
p->who();

p= &c;
p->who();
return 0;
}