#include<iostream>
#include<cstdlib>

using namespace std;

void handler(int t) throw( char *, double)
{
	try
	{
		if (t == 1)
			throw t;
		if (t == 2)
			throw "it is 2";
		if (t == 3)
			throw 3.01;
		if (t == 4)
			throw 'c';
	}
	catch(int e)
	{
		cout << " got integer of " << e << '\n';
	}
	catch(...)
	{
		cout << "got one\n";
	}
}

int main()
{
	handler(1);
	handler(2);
	handler(3);
	handler(4);
	 return 0;
}