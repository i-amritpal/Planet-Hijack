#include <iostream>
#include <cstdlib>
using namespace std;

const int SIZE = 3;

class arr
{
	int a[SIZE];
  public:
	  arr()
	{
		register int k;
		for (k = 0; k < SIZE; k++)
			  a[k] = 0;
	}

	int &operator[] (int m)
	{
		if (m < 0 || m > SIZE - 1)
		{
			cout << m << " is out of bounds";
			exit(1);
		}
		return a[m];
	}
};

int main()
{
arr p;
p[0] = 23;
p[1] = 2;
cout << p[0] << p[1];
p[3] = 8;
	return 0;
}