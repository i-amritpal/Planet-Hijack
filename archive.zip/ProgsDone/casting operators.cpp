#include<iostream>
#include<typeinfo>
using namespace std;
class base
{
	virtual void f()
	{
	}
};
class derived: public base
{
};
int main()
{
	base *bp, bob;
	derived *dp, dob;

	bp = &dob;
	dp = dynamic_cast < derived * >(bp);
	if (dp)
		cout << "Cast of bp to dp containing dob obj success" << endl;


	bp = dynamic_cast < base * >(dp);
	if (bp)
		cout << "Cast of dp to bp containing dob success\n";
}

