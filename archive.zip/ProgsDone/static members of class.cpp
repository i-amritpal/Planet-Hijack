#include<iostream>

using namespace std;

void space(int x)
{
	for (; x;x--)
	{
		cout << ' ';
	}
	cout << "|\n";
}

void space(char ch, int x)
{
	for (; x; x--)
	{
		cout << ch;
	}
	cout << "|\n";
}

int main()
{
	void (*p1) (int h);
	void (*p2) (char, int);
	p1 = space;
	p2 = space;
	(*p1) (12);
	(*p2) ('x', 15);
	 return 0;
}