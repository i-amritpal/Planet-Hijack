#include <iostream>

using namespace std;

class base1
{
	int j;

  protected:
	void setj(int m)
	{
		j = m;
	}
	int getj()
	{
		return j;
	}
};

class base2
{
	int l;
  protected:
	void setl(int a)
	{
		l = a;
	}
	int getl()
	{
		return l;
	}
};

class derived:public base1,base2
{
	int k;
  public:
	void set(int a, int b,int c)
	{
		setj(a);
		k = b;
setl(c);
	}
	void show()
	{
		cout << getj() << " " << k << " " <<getl();
	}
};

int main()
{
	derived ob;
	ob.set(5, 6,7);
	ob.show();
	return 0;
}