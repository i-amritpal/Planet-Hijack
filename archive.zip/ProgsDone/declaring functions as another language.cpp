#include<iostream>

using namespace std;
extern "C" void sh();
void sh()
{
	cout << "Thus is implemented as a c function \n";
}
int main ()
{
sh();
return 0;
}
