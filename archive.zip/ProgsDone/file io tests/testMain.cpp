#include<iostream>
#include<fstream>
using namespace std;
int main()
{
	int x;
	double y;
	char s[80];
	ifstream test("test");

	if (!test)
	{
		cout << "File opening failed \n";
		return 1;
	}
	test >> x >> y >> s;

	cout << x << endl;
	cout << y << endl;
	cout << s << endl;

	test.close();

	ofstream test2("test");
	if (!test2)
	{
		cout << " File opening failed \n";
		return 1;
	}

	test2 << 123 << 123.4 << "Simran";
	test2.close();
	 return 0;
}