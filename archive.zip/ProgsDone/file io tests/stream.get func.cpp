#include<iostream>

using namespace std;

int main ()
{
char s[80];

cin.get(s, 79);

cout << s;
return 0;
}