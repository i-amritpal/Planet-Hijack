#include<iostream>
#include<fstream>
#include<cstdlib>

using namespace std;

int main (int argc, char* argv[])
{
ifstream in(argv[1], ios::in | ios::binary);

if(!in)
{
cout << "File not opened\n";
return 1;
}

char ch = in.peek();
char ch2;

in.get(ch2);

cout << ch << ch2;

in.close();
return 0;
}