#include<iostream>
#include<fstream>

using namespace std;

int main()
{
	ofstream out("test2", ios::out | ios::binary);

	if (!out)
	{
		cout << "File not opened \n";
		return 1;
	}

	char *s = " hello there ";

	while (*s)
	{
		out.put(*s++);
	}

	out.close();
	return 0;
}