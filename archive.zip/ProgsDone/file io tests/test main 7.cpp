#include<iostream>
#include<fstream>
#include<cstdlib>

using namespace std;

int main(int argc, char *argv[])
{
	fstream out(argv[1], ios::in | ios::out | ios::binary);

	if (!out)

	{
		cout << "File not opened\n";
		return 1;
	}
	char ch;
	int pos = out.tellp();

	cout << pos << endl;

	out.seekg(atoi(argv[2]), ios::beg);
	if (!out.good())
	{
		cout << " Input/output error" << endl << "Clearing the ios flags" << endl;
		out.clear();
	}

	while (out.get(ch))
		cout << ch;
	out.close();
	return 0;
}