#include<iostream>
#include<fstream>
#include<cstdlib>

using namespace std;

class three_d
{
	int x, y, z;

  public:
	  three_d(int a, int b, int c)
	{
		x = a;
		y = b;
		z = c;
	}
	friend ofstream & operator<<(ofstream & stream, three_d ob);
};

ofstream & operator<<(ofstream & stream, three_d ob)
{
	stream << ob.x << ',' << ob.y << ',' << ob.z << '\n';
	return stream;
}

int main(int argc, char *argv[])
{
	three_d a(1, 2, 3), b(4, 5, 6), c(7, 8, 9);
	ofstream out("threed");
	if (!out)
	{
		cout << "Filenot opened\n";
		return 1;
	}
	out << a << b << c;
	out.close();
	return 0;
}