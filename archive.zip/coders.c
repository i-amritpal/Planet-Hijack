#include<stdio.h>
#include<conio.h>
#include<math.h>

int main()
{
int i,p;
printf("Enter the no of elements");
scanf("%d",&p);
int a[p];
for (i=0;i<=p;i++)
{
printf(" enter the num[%d]= %d \n",i,a[i]);
scanf("%d",&a[i]);
}

do {

while (a[2]<=9)
{
a[2]=a[2]-1;

if (a[2]==0 && a[1]!=0)
{
a[2] = 9;
a[1]= a[1]-1;
}

if (a[2]==0 && a[1]==0)
{
a[2] = 9 , a[1]=9;
a[0]= a[0]-1;
}
}
for (i=0;i<=p;i++)
{
printf( "enter the num[%d]= %d \n", i , a[i]);
}
} while (p<4);
getch();
}