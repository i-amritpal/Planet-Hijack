// Actual Library Management Project
#include<iostream>
#include<cstring>
#include<fstream>
#include<conio.h>

const char login_file_name[] = "login_record.db";
const char emp_file_name[] = "emp_record.db";
// const char 


using namespace std;

struct login_data
{
	char name[20];
	char password[20];
};

struct date
{
	int dd, mm, yy;
	  date()
	{
		dd = mm = yy = 0;
	}

	void set_date(int d, int m, int y)
	{
		dd = d;
		mm = m;
		yy = y;
	}
};

struct details
{
	int code;
	char name[20];
};

struct product : public details
{
// code , name
int price;
};

struct recipt : public details
{
// code -> recipt no
// name
};

struct vendor : public details
{
// code , name
char address[20];
char phone_no[11];
};

struct costumer : vendor
{
// no more code
};

class employee
{
   public:
	int code;
	char name[20];
	char address[20];
	char phone_no[11];
	date date_of_joining;
	char designation[20];
	double salary;

	  employee()
	{
		strcpy(name, "EMP DUMMY");
		strcpy(address, "ADDRESS DUMMY");
	}


};