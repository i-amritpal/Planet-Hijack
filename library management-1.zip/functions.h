/// Functions

#include<iostream>
#include<cstring>
#include<cstdlib>
#include<fstream>
#include"structs.h"

using namespace std;

int record_list(char *fname);
void master();
void transaction();
void report();
void billing();
void edit_emp_record();
int search();
void show_emp_record();
int substrcmp(char *, char *);

int record_list(char *fname)
{
	employee *ptr = new employee;

	int emp_count = 1;
	
	fstream file(fname);
	
	if(file)
	{	
		// Outputting of emps (minimal info) from file to screen starts here
		
		while(!file.eof() && file.peek() != EOF)
		{
			file.read((char *) ptr , sizeof(employee));
			
			cout << ptr->code << " " << ptr->name << '\n';
		}
	}
	else
		cout << "File Not opened: EMPLOYEE RECORD!\n";
	
	file.close();

delete ptr;
	return emp_count;
}

bool login()
{
	bool login_status = false;
	char n[20];
	char pswd[10];
	login_data lgn;
	
	// The First screen of the program
	cout << "\n-------Login Menu--------\n"
	<< "->Enter the name: ";
	cin.getline(n,20);
	cout << "->Enter the password: ";
	cin.getline(pswd, 10);
	
	// Name and password extraction from file and checking
	fstream file(login_file_name);
	if(!file)
	{
		cout << "File not opened: LOGIN RECORD!\n";
	}
	else{
		
		file.read((char *) &lgn, sizeof(login_data));
		
		//cout << "DEBUG: " << lgn.name << ' ' << lgn.password << '\n';
		
		if((!strcmp(lgn.name, n)) && (!strcmp(lgn.password, pswd)))
			login_status = true;
		else
			login_status = false;
	}
	file.close();
	// Return the login status
	return login_status;
}

void menu()
{
	/// 1. Master 2. Transaction 3. Report s 4. Billing 5. exit
	// 1. a emp b prdouct c vendor d custmer
	/// in Master edit the records of emp, prod....
	
	short int ch = -1;
	
	while(ch != 0)
	{
		cout << "\nThe MAIN MENU:\n"
		<< "1. Master\n"
		<< "2. Transaction\n"
		<< "3. Report\n"
		<< "4. Billing\n"
		<< "0. Exit\n";
		cout << "->Enter Choice:";
		cin >> ch;
		
		switch(ch)
		{
			case 1:
				master();
				break;
			
			case 2:
				//transaction();
				break;
			
			case 3:
				//report();
				break;
			
			case 4:
				//billing();
				break;
				
			case 0:
				//No Code
				cout << "____Exitting Main Menu____";
				break;
			
			default:
				cout << "In-Valid Code!\n";
				break;
		}
	}
}

void master()
{
	short int a = -1;
	cout << "\n\t-------Master Record Menu-------\n"
	<< "\tEdit the Records:\n"
	<< "\t1. Employee\n"
	<< "\t2. Product\n"
	<< "\t3. Vendor\n"
	<< "\t4. Costumer\n"
	<< "\t0. Exit\n";
	cout << "\t->Enter Choice:";
	cin >> a;
	
	switch(a){
		case 1:
			edit_emp_record();
			break;
		
		case 2:
			//edit_product_record();
			break;
		
		case 3:
			//edit_vendor_record();
			break;
		
		case 4:
			//edit_costumer_record();
			break;
		
		case 0:
				//No Code
				cout << "\t____Exitting Master Record Menu____\n";
				break;
		
		default:
			cout << "In-Valid Code!\n";
	}
}

void edit_emp_record()
{
	fstream file(emp_file_name);
	if(!file)
	{
		cout << "File not Opened : EMPLOYEE RECORD!\n";
	}
	else{
		int record_no = search();
		cout << "Debug: RECORD NUMBER: " << record_no << '\n';
	}
	file.close();
}

int search()
{
	int temp= -1, itr =0;
	int record_number = -1;
	fstream file(emp_file_name);
	employee emp;
	
	if(!file)
	{
		cout << "File not Opened : EMPLOYEE RECORD!\n";
	}
	else{
		short int ch = -1;
		cout << "\n\t#Employee Record Search Menu#\n";
		
		while(ch == -1)
		{
			cout
			<< "\t1. Search by Employee Code\n"
			<< "\t2. Search by Employee Phone Number\n"
			<< "\t3. Search by Employee Name/Address\n"
			<< "\t0. Cancel Record Search\n";
			cout << "\t->Enter Choice:";
			cin >> ch;
			
			switch(ch)
			{
				case 1:
					cout << "\t->Enter Employee Code:";
					cin >> temp;
					
					// Search for the employee Number via emp_code
					while(!file.eof() && record_number == -1)
					{
						itr++;
						file.read((char *) &emp , sizeof(employee));
						if(emp.code == temp)
						{
							record_number = itr;
						}
					}
					
					break;
				
				
				case 2:
					char ph[11];
					cout << "\t->Enter Employee Phone No.:";
					cin >> ph;
				
					// Search for the employee Number via emp_phone_number
					while(!file.eof() && record_number == -1)
					{
						itr++;
						file.read((char *) &emp , sizeof(employee));
						if(strcmp(emp.phone_no, ph) == 0)
						{
							record_number = itr;
						}
					}
					break;

				case 3:
					
					int m;
					m = 0;
					int rec_nos_elmts;
					rec_nos_elmts = 20;
					int * rec_nos;
					rec_nos = new int[rec_nos_elmts];
					
					char string[20];
					
					cout << "\t->Enter the name/address of Employee: ";
					cin >> string;
					//cin.getline(string, sizeof(string));
					
					//Search for the name/address of employee
					// Done: TODO: Implement or add the substring compare method
					
					while(!file.eof() && record_number == -1)
					{	
						itr++;
						file.read((char *) &emp , sizeof(employee));
						if(substrcmp(emp.name , string))
						{
							
							// Grow the array to hold more elements
							if(m == rec_nos_elmts)
							{
								int *temp;
								temp = new int[rec_nos_elmts+20];
								for(int j = 0; j < rec_nos_elmts; j++)
								{
									temp[j] = rec_nos[j];
								}
								
								delete []rec_nos;
								rec_nos = temp;
							}
							
							
							rec_nos[m] = itr;
							m++;
						}
					}
					
					cout << "\t  #Found Records are:\t";
					for(int i = 0; i < m; i++)
					{
						cout << "\t  " << i+1 << ". " << rec_nos[i] << "\n"; 
					}
					
					delete []rec_nos;
					
					break;
				
				case 4:
					cout << "\t#Search Cancelled!\n";
					// No Code
					break;
			}
		}
		
	}
	file.close();
	
	return record_number;
}

void show_emp_record(int rc_no)
{
	cout << "Debug: Record No. is: " << rc_no<< '\n';
}


int substrcmp(char *smain, char *ssub)
{
	bool x;
	
	for(int i = 0; smain[i] != '\0' && smain != false ; i++)
	{	
	// Error cout << "Debug: " << toupper(smain[i+k]) << " " << toupper(ssub[i]) << "\n";
		if(toupper(smain[i]) == toupper(ssub[0])) 
		{
			x = true;
			for(int k = 0; ssub[k] != '\0'; k++)
			{
				if(smain[i+k] != ssub[k]) 
				{
					x =false;
				}
			}
		}
	}
	
	return x;
}