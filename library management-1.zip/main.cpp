// Industry Management Project
// ### Main.cpp ###
#include<iostream>
#include "functions.h"

using namespace std;

int main()
{
	{
	/*
	login_data tmp;
	strcpy(tmp.name, "simran");
	strcpy(tmp.password, "abc");
	
	
	fstream f("login_record.db");
	
	f.write((char *) &tmp, sizeof(login_data));
	
	f.close();
	//*/
	
	
	//remove("temp.db");
	}

	{/*
		employee emp1;
		strcpy(emp1.name, "simran");
		strcpy(emp1.address, "#123,MGG");
		strcpy(emp1.designation, "student");
		emp1.code = 21;
		emp1.date_of_joining.set_date(1, 12, 1999);
		emp1.salary = 12345;
		strcpy(emp1.phone_no, "9988776655");
		
		employee emp2;
		strcpy(emp2.name, "Amrit");
		strcpy(emp2.address, "#123,MGG");
		strcpy(emp2.designation, "student");
		emp2.code = 22;
		emp2.date_of_joining.set_date(1, 11, 2001);
		emp2.salary = 15678;
		strcpy(emp2.phone_no, "8888877777");
		
		employee emp3;
		strcpy(emp3.name, "JP");
		strcpy(emp3.address, "#433,MGG");
		strcpy(emp3.designation, "student");
		emp3.code = 23;
		emp3.date_of_joining.set_date(9, 9, 1999);
		emp3.salary = 55555;
		strcpy(emp3.phone_no, "7777766666");
		
		employee emp4;
		strcpy(emp4.name, "JSL");
		strcpy(emp4.address, "#001,MGG");
		strcpy(emp4.designation, "musician");
		emp4.code = 24;
		emp4.date_of_joining.set_date(1, 1, 1990);
		emp4.salary = 66666;
		strcpy(emp4.phone_no, "1111122222");
		
		fstream file(emp_file_name);
		file.write((char *) &emp1, sizeof(employee));
		file.write((char *) &emp2, sizeof(employee));
		file.write((char *) &emp3, sizeof(employee));
		file.write((char *) &emp4, sizeof(employee));
		file.close();
	//*/
	}
	
	if(login())
	{
		menu();
	}
	else {
		cout << "Login Unsuccessful!";
	}
	
	return 0;
}