// / Functions

#include<iostream>
#include<cstring>
#include<cstdlib>
#include<fstream>
#include"structs.h"

using namespace std;

int record_list(char *fname);
void master();
void transaction();
void report();
void billing();
void edit_emp_record();
int search();
void show_emp_record(int);
int substrcmp(char *, char *);

int record_list(const char *fname)
{
	employee *ptr = new employee;

	int emp_count = 1;

	fstream file(fname);

	if (file)
	{
		// Outputting of emps (minimal info) from file to screen starts here

		while (!file.eof())
		{
			file.read((char *)ptr, sizeof(employee));

			cout << "\t" << ptr->code << " " << ptr->name << '\n';
		}
	}
	else
		cout << "File Not opened: EMPLOYEE RECORD!\n";

	file.close();

	delete ptr;
	return emp_count;
}

bool login()
{
	bool login_status = false;
	char n[20];
	char pswd[10];
	login_data lgn;

	// The First screen of the program
	cout << "\n-------Login Menu--------\n" << "->Enter the name: ";
	cin.getline(n, 20);
	cout << "->Enter the password: ";
	cin.getline(pswd, 10);

	// Name and password extraction from file and checking
	fstream file(login_file_name);
	if (!file)
	{
		cout << "File not opened: LOGIN RECORD!\n";
	}
	else
	{

		file.read((char *)&lgn, sizeof(login_data));

		// cout << "DEBUG: " << lgn.name << ' ' << lgn.password << '\n';

		if ((!strcmp(lgn.name, n)) && (!strcmp(lgn.password, pswd)))
			login_status = true;
		else
			login_status = false;
	}
	file.close();
	// Return the login status
	return login_status;
}

void menu()
{
	// / 1. Master 2. Transaction 3. Report s 4. Billing 5. exit
	// 1. a emp b prdouct c vendor d custmer
	// / in Master edit the records of emp, prod....

	short int ch = -1;

	while (ch != 0)
	{
		cout << "\nThe MAIN MENU:\n"
			<< "1. Master\n"
			<< "2. Transaction\n" << "3. Report\n" << "4. Billing\n" << "0. Exit\n";
		cout << "->Enter Choice:";
		cin >> ch;

		switch (ch)
		{
		case 1:
			master();
			break;

		case 2:
			// transaction();
			break;

		case 3:
			// report();
			break;

		case 4:
			// billing();
			break;

		case 0:
			// No Code
			cout << "____Exitting Main Menu____";
			break;

		default:
			cout << "In-Valid Code!\n";
			break;
		}
	}
}

void master()
{
	short int a = -1;
	cout << "\n\t-------Master Record Menu-------\n"
		<< "\tEdit the Records:\n"
		<< "\t1. Employee\n"
		<< "\t2. Product\n" << "\t3. Vendor\n" << "\t4. Costumer\n" << "\t0. Exit\n";
	cout << "\t->Enter Choice:";
	cin >> a;

	switch (a)
	{
	case 1:
		edit_emp_record();
		break;

	case 2:
		// edit_product_record();
		break;

	case 3:
		// edit_vendor_record();
		break;

	case 4:
		// edit_costumer_record();
		break;

	case 0:
		// No Code
		cout << "\t____Exitting Master Record Menu____\n";
		break;

	default:
		cout << "In-Valid Code!\n";
	}
}

void edit_emp_record()
{
	fstream file(emp_file_name);
	employee emp;
	 employee emp2;
	int x = 1;
	int rc_no = -1;
rc_no = search();
	if (!file)
	{
		cout << "File not Opened : EMPLOYEE RECORD!\n";
	}
	else
	{
		show_emp_record(rc_no);
		int found = 0;
		char name[20];
		char address[20];
		char phone[11];
		cout << "Enter name: ";
		cin >> name;
		cout << "Enter address: ";
		cin >> address;
		cout << "Enter phone no. :";
		cin >> phone;

		strcpy(emp.name, name);
		strcpy(emp.address, address);
		strcpy(emp.phone_no, phone);

		while (!file.eof() && found == 0)
		{
			file.read((char *)&emp2, sizeof(employee));
			if (x == rc_no && x <= rc_no)
			{
				int pos = -1 * sizeof(employee);
				file.seekp(pos, ios::cur);
				file.write((char *)&emp, sizeof(employee));
				cout << "\n\n\t Record Updated";
				found = 1;
			}
			x++;
		}
	}
	file.close();
}

int search()
{
	int temp = -1, itr = 0;
	int record_number = -1;
	fstream file(emp_file_name);
	employee emp;

	// test
	if (!file)
	{
		cout << "File not Opened : EMPLOYEE RECORD!\n";
	}
	else
	{
		short int ch = -1;
		cout << "\n\t#Employee Record Search Menu#\n";

		while (ch == -1)
		{
			cout << "\t1. Search by Employee Code\n"
				<< "\t2. Search by Employee Phone Number\n"
				<< "\t3. Search by Employee Name/Address\n" << "\t0. Cancel Record Search\n";
			cout << "\t->Enter Choice:";
			cin >> ch;

			if (ch == 1)
			{
				cout << "\t->Enter Employee Code:";
				cin >> temp;

				// Search for the employee Number via emp_code
				while (!file.eof() && record_number == -1)
				{
					itr++;
					file.read((char *)&emp, sizeof(employee));
					if (emp.code == temp)
					{
						record_number = itr;
					}
				}
			}
			else if (ch == 2)
			{
				char ph[11];
				cout << "\t->Enter Employee Phone No.:";
				cin >> ph;

				// Search for the employee Number via emp_phone_number
				while (!file.eof() && record_number == -1)
				{
					itr++;
					file.read((char *)&emp, sizeof(employee));
					if (strcmp(emp.phone_no, ph) == 0)
					{
						record_number = itr;
					}
				}
			}
			else if (ch == 3)
			{
				int m = 0;
				int rec_no_elmts = 20;
				int rec_nos[20];
				int tp = 0;
				char string[20];

				cout << "\t->Enter the name/address of Employee: ";
				cin >> string;

				while (!file.eof() && record_number == -1)
				{
					itr++;
					file.read((char *)&emp, sizeof(employee));
					if (substrcmp(emp.name, string))
					{
						rec_nos[m] = itr;
						m++;
					}
				}

				file.close();
				file.open(emp_file_name);

				cout << "\t  #Found Records are:\n";
				for (int i = 0, j = 0; !file.eof() && i < m; j++)
				{
					file.read((char *)&emp, sizeof(employee));

					if (j == (rec_nos[i] - 1))
					{
						cout << "\t\t    " << i +
							1 << " . " << emp.name << " - " << emp.phone_no << '\n';

						i++;
					}
				}

				if (m == 0)
				{
					cout << "\t\tNo Records Found!\n";
				}
				else
				{
					cout << "\t\t->Enter your choice: ";
					cin >> tp;
					record_number = rec_nos[tp - 1];
				}
			}
			else if (ch == 4)
			{
				cout << "\t#Search Cancelled!\n";
				// No Code
				break;
			}
		}

	}
	file.close();

	return record_number;
}

void show_emp_record(int rc_no)
{
	fstream file(emp_file_name);
	employee emp;
	int x = 1;

	if (!file)
	{
		cout << "File not Opened : EMPLOYEE RECORD!\n";
	}
	else
	{

		while (!file.eof())
		{
			file.read((char *)&emp, sizeof(employee));
			if (x == rc_no && x <= rc_no)
			{
				cout << " \n\t\t Employee Code - " << emp.
					code << " \n\t\t Name - " << emp.name << "\n\t\t Ph. No. - " << emp.
					phone_no << "\n\t\t Designation - " << emp.designation << "\n";
			}
			x++;
		}
	}

	// record_list(emp_file_name);
	file.close();
}


int substrcmp(char *smain, char *ssub)
{
	bool x = false;

	for (int i = 0; smain[i] != '\0' && x == false; i++)
	{
		if ((toupper(smain[i]) == toupper(ssub[0])))
		{
			x = true;
			for (int k = 0; ssub[k] != '\0'; k++)
			{
				if ((toupper(smain[i + k]) != toupper(ssub[k])) && x == true)
				{
					x = false;
				}
			}
		}
	}

	return x;
}




int main()
{
	{
		/* 
		   login_data tmp; strcpy(tmp.name, "simran"); strcpy(tmp.password,
		   "abc");


		   fstream f("login_record.db");

		   f.write((char *) &tmp, sizeof(login_data));

		   f.close(); // */


		// remove("temp.db");
	}

	{							/* 
								   employee emp1; strcpy(emp1.name, "simran");
								   strcpy(emp1.address, "#123,MGG");
								   strcpy(emp1.designation, "student");
								   emp1.code = 21;
								   emp1.date_of_joining.set_date(1, 12, 1999);
								   emp1.salary = 12345; strcpy(emp1.phone_no,
								   "9988776655");

								   employee emp2; strcpy(emp2.name, "Amrit");
								   strcpy(emp2.address, "#123,MGG");
								   strcpy(emp2.designation, "student");
								   emp2.code = 22;
								   emp2.date_of_joining.set_date(1, 11, 2001);
								   emp2.salary = 15678; strcpy(emp2.phone_no,
								   "8888877777");

								   employee emp3; strcpy(emp3.name, "JP");
								   strcpy(emp3.address, "#433,MGG");
								   strcpy(emp3.designation, "student");
								   emp3.code = 23;
								   emp3.date_of_joining.set_date(9, 9, 1999);
								   emp3.salary = 55555; strcpy(emp3.phone_no,
								   "7777766666");

								   employee emp4; strcpy(emp4.name, "JSL");
								   strcpy(emp4.address, "#001,MGG");
								   strcpy(emp4.designation, "musician");
								   emp4.code = 24;
								   emp4.date_of_joining.set_date(1, 1, 1990);
								   emp4.salary = 66666; strcpy(emp4.phone_no,
								   "1111122222");

								   fstream file(emp_file_name);
								   file.write((char *) &emp1,
								   sizeof(employee)); file.write((char *)
								   &emp2, sizeof(employee)); file.write((char
								   *) &emp3, sizeof(employee));
								   file.write((char *) &emp4,
								   sizeof(employee)); file.close(); // */
	}

	// if (login())
	{
		menu();
	}
	// else
	{
		// cout << "Login Unsuccessful!";
	}


	return 0;
}