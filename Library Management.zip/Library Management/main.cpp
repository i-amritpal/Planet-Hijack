// Library Management Project
#include<iostream>
#include<string>
#include<cstdlib>

using namespace std;

struct date_type
{
	int dd, mm, yy;
};

class book_type
{
  public:
	char *name;
	char *author;
	char *publisher;
	bool available;
	date_type issue_date;

	book_type *next;

	  book_type(char *n)
	{
		strcpy(name, n);
		author = publisher = 0;
		available = false;
		issue_date.dd = issue_date.mm = issue_date.yy = 0;
		next = 0;
	}
};

class manager_type
{
	book_type *start;

  public:
	  manager_type()
	{
		start = 0;
	}

	manager(char *n)
	{
		start = new book_type(n);
	}

	void add(char *n)
	{

	} 

 void insert()
	{
		book_type *loc;
		char s[20];
		cout << "Enter name of book after which book to add:";
		cin.getline(s, 20);
		loc = search(s);

		if (loc = 0)
		{
			cout << " Book not found\n";
		}
		else
		{
			book_type *ptr;
			ptr = new book_type;
			cout << "Enter name of new book: ";
			cin.get(ptr->name, 20);
			loc->next = ptr;
		}


	}

	book_type *search(char *n)
	{
		book_type *ptr;
		ptr = start;
		while (ptr != 0)
		{
			if (strcmp(ptr->name, n))
				return (ptr);
			ptr = ptr->next;
		}
		return 0;
	}

	void delete_book()
	{
		if (start = 0)
		{
			cout << " Underflow";
		}
		else
		{
			char s[20];
			cout << "Enter name of book to be deleted: ";
			cin.getline(s, 20);
			if (strcmp(start->name, s))
			{
				book_type *save = start;
				start = start->next;
				delete save;
			}
			else
			{
				// Else code to go
				book_type *prev, *ptr;
				prev = start;
				ptr = start->next;

				while (ptr != 0)
				{
					if (strcmp(ptr->name, s))
					{
						prev->next = ptr->next;
						delete ptr;
					}
					else
					{
						prev = ptr;
						ptr = ptr->next;
					}

				}
			}
		}
	}

	~manager_type()
	{
		book_type *ptr = start;
		while (ptr != 0)
		{
			ptr = ptr->next;
			delete start;
			start = ptr;
		}
	}
};

int main()
{

	return 0;
}