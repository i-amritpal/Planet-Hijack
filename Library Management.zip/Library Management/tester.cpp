// Tester
#include<iostream>
#include<cstring>
#include<fstream>

using namespace std;

struct information
{
	char name[20];
	char author[20];
  public:
	  information()
	{
		strcpy(name, "dummy");
		strcpy(author, "dummy Author");
	}

};

struct book
{
	information info;
	book *next;

	  book()
	{
		next = 0;
	}
	book(char *n)
	{
		strcpy(info.name, n);
		next = 0;
	}
};

int main()
{
	book d("Test");
	book db("Test2 and main");

	book r;

	strcpy(db.info.author, "TheAuthor");

	fstream file("BOOKS.DAT");
//	file.write((char *) &d, sizeof (book));
//	file.write((char *) &db, sizeof (book));


	file.read((char *)&r, sizeof(book));
	cout << "Book : " << r.info.name << " by " << r.info.author;
	file.read((char *)&r, sizeof(book));
	cout << "Book : " << r.info.name << " by " << r.info.author;

	file.close();
	// cout << d.info.name;
	return 0;
}